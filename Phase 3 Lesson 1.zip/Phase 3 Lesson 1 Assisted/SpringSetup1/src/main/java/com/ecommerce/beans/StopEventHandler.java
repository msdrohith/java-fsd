package com.ecommerce.beans;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextStoppedEvent;

public abstract class StopEventHandler implements
ApplicationListener<ContextStoppedEvent>{
	
	public void sonApplicationEvent(ContextStoppedEvent event){
		System.out.println("ContextStoppedEvent Received");
	}
}
